package com.jspiders.hibernate.dao;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import com.jspiders.hibernate.dto.UFODTO;
public class UFODAO {
	public void saveUFO(UFODTO dto) {
		//Component 1
		Configuration cfg = new Configuration();
		cfg.configure();
				
		//Component 2
		SessionFactory factory = cfg.buildSessionFactory();
		
		//Component 3
		Session session = factory.openSession();
		
		//Sub-component 1 of session
		Transaction tx = session.beginTransaction();
			session.save(dto);
			tx.commit();
			session.close();
			factory.close();
	}
}




