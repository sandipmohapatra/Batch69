import java.sql.*;
import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class result extends HttpServlet
 {
 
public void init()
{
System.out.println("init");
 
}

    public void doGet(HttpServletRequest req, HttpServletResponse res)throws ServletException, IOException 
{
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
       int value = (int)(Math.random() * 9999);

out.println("<h2>");
out.println("<h2>Your Result is +</h2>");
out.println("</h2>");
if(value>5)
{
out.println("<h2>Your have Passed ! Congrats </h2>");
out.println("<a href=index.html>Apply For Job</a>");
}
else
{
out.println("<h2>Your have Failed ! Try Again...... </h2>");
res.sendRedirect("login.html");
}		 
  

 
           
	
            out.println("</body>");
            out.println("</html>");
              } 

 
}