import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@WebServlet("/LoginPage")
public class LoginPage extends HttpServlet 
{
public void service(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
{
	res.setContentType("text/html");
	PrintWriter pw=res.getWriter();
	String a=req.getParameter("t1");
	String b=req.getParameter("t2");
	try
	{
	Class.forName("oracle.jdbc.driver.OracleDriver");
	Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "1234");
	PreparedStatement st = con.prepareStatement("select * from wiproreg69 where name=? and password=?");
	st.setString(1,a);
	st.setString(2,b);
	ResultSet rs=st.executeQuery();
	int i=0;
	while(rs.next())
	{
		i++;
	}
	if(i==1)
	res.sendRedirect("success.html");
	else
					res.sendRedirect("Login.html");
			}
	catch(Exception ae)
	{
		pw.println("The error is :"+ae);
	}}}
