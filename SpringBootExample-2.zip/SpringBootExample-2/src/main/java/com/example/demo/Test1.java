package com.example.demo;
import org.springframework.stereotype.Component;
//ctrl+shift+O
@Component("test")
public class Test1 
{
public void welcome()
{
	System.out.println("welcome to Rest WebServices");
}
public int sum(int a,int b)
{	return a+b;}

public int sub(int a,int b)
{return a-b;}
}
