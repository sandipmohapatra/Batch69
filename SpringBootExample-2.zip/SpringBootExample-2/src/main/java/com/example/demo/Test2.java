package com.example.demo;

import org.springframework.stereotype.Component;

//ctrl+shift+O
@Component("test1")
public class Test2 
{
public void welcomeWipro()
{
	System.out.println("welcome to Rest WebServices Wipro Batch-37");
}
public int mul(int a,int b)
{
	return a*b;
}

public int div(int a,int b)
{
	return a / b;
}

}
