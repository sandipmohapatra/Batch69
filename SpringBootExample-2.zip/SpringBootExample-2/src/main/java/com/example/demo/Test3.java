package com.example.demo;

import org.springframework.stereotype.Component;

@Component("test2")
public class Test3 
{
public int square(int i)
{
	return i*i;
}
}
