package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootExample3Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootExample3Application.class, args);
	}

}

//create table register215 (name varchar2(30),address varchar2(30),
//phoneno varchar2(30),email varchar2(30),salary varchar2(30),
//design varchar2(30),gender varchar2(30),nation varchar2(30),
//hobby varchar2(30))