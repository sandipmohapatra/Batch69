package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class SpringBootExample1Application {

	public static void main(String[] args) 
	{
		ApplicationContext ac=SpringApplication.run(SpringBootExample1Application.class, args);
		MyBatch37 mb=ac.getBean("msg",MyBatch37.class);
		mb.welcome();
		System.out.println("The sum is "+mb.sum(67,54));
	}

}
