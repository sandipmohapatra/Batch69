package com.cognizant.fsd.restfulapiassignment1.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.fsd.restfulapiassignment1.model.Book;
import com.cognizant.fsd.restfulapiassignment1.service.BookStoreService;
@CrossOrigin(origins = "http://localhost:3000")
@RestController
public class BookStoreController {
	@Autowired
	private BookStoreService bookStoreService;
	
	@GetMapping("/bookstore/books/{bookId}")
	public Book getBookById(@PathVariable String bookId) {
		Book bookDetails = bookStoreService.getBookById(Long.parseLong(bookId));
		return bookDetails;
	}
	
	@GetMapping("/bookstore/books")
	public List<Book> getAllBook(){
		List<Book> allBookList = bookStoreService.getAllBooks();
		return allBookList;
	}
	
	@RequestMapping(method = RequestMethod.POST, value="/bookstore/books")
	public void addBook(@RequestBody Book book) {
		System.out.println("Adding Book..");
		 bookStoreService.addBook(book);
		
	}
	
	@RequestMapping(method=RequestMethod.PUT, value="/bookstore/books/{bookId}")
	public void editBook(@RequestBody Book book,@PathVariable String bookId) {
		bookStoreService.editBook(book,Long.parseLong(bookId));
		
	}
	
	@RequestMapping(method=RequestMethod.DELETE,value="/bookstore/books/{bookId}")
	public void deleteBook(@PathVariable String bookId) {
		bookStoreService.deleteBook(Long.parseLong(bookId));
		
	}
	
	
}	
