package in.nit.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Component;

import in.nit.repo.ProductRepository;

//@Component
public class ProductTestRunnerSort implements CommandLineRunner{
	@Autowired
	private ProductRepository repo;
	
	@Override
	public void run(String... args) throws Exception {
		//select * from product order by prod_code asc
		//Sort sort=Sort.by("prodCode");
		
		//select * from product order by prod_code desc
		Sort sort=Sort.by(Direction.DESC,"prodCode");
		repo.findAll(sort)
		.forEach(System.out::println);
	}
}
